class FilmlerNesnesi {
  int film_id;
  String film_adi;
  String film_resim_adi;
  int film_fiyat;

  FilmlerNesnesi({
    required this.film_id,
    required this.film_adi,
    required this.film_resim_adi,
    required this.film_fiyat,
  });
}
